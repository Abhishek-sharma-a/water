import React from 'react'

const Butt = (props) => {
  return (
    <>
<span>
<button className='reButt rounded-pill ms-2 mt-3' >{props.btnName}</button>

</span>
    </>
  )
}

export default Butt

// ok