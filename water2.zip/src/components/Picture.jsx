import React from 'react'
import  "../components/Picture.css"
const Picture = (props) => {
  return (
  <>
 <img src={props.pix} alt="" />
  
  </>
  )
}

export default Picture

