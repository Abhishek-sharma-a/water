import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
const Dashboard = () => {
    const [user, setUser] = useState(JSON.parse(localStorage.getItem("user")))
    console.log(JSON.parse(localStorage.getItem("user")));
    useEffect(
        () => {
            setUser(JSON.parse(localStorage.getItem("user")))
            console.log(user, "xxfdyf");
        }, [localStorage.getItem("user")])
       
    return (
        <div>Dashboard


            {user?.id}
            {user?.displayName}




        </div>
    )
}

export default Dashboard