import React from 'react'

import "./Card.css"

const Card = (props) => {
  return (
    <> <div className='clas'> <div className='card'>

      <img src={props.i} alt="" />

    </div>
      <h3>{props.h}</h3>

      <p>Lorem ipsum consectetur <br /> adipisperiores voluptatem?</p></div>

    </>)
}

export default Card         


// ;hifj'hoi
